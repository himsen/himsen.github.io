import java.io.*;
import java.math.*;
public class statTheory {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try{
			FileWriter writer = new FileWriter("theoryMult.txt");
			BufferedWriter bufWriter = new BufferedWriter(writer);
			for(int i = 15; i < 50+1; i++){ 
				bufWriter.write(Double.toString( 8*Math.exp( Math.sqrt( 2*Math.log(Math.pow(2,i))*Math.log(Math.log(Math.pow(2,i)))) ) ) );
				bufWriter.newLine();
			}
			bufWriter.close();
			writer.close();
		}
		catch(IOException e){
			e.printStackTrace();
		}

		try{
			FileWriter writer = new FileWriter("theoryCurves.txt");
			BufferedWriter bufWriter = new BufferedWriter(writer);
			for(int i = 15; i < 50+1; i++){ 
				bufWriter.write(Double.toString( Math.exp( Math.sqrt( (0.5)*Math.log(Math.pow(2,i))*Math.log(Math.log(Math.pow(2,i)))) ) ) );
				bufWriter.newLine();
			}
			bufWriter.close();
			writer.close();
		}
		catch(IOException e){
			e.printStackTrace();
		}

	}

}
